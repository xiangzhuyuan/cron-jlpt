require 'faraday'
require 'json'
require 'nokogiri'
require 'erb'

@connection = Faraday.new('http://www3.nhk.or.jp/news/easy/') do |builder|
  builder.request :url_encoded
  builder.response :logger
  builder.adapter Faraday.default_adapter
end
@connection.headers[:user_agent] = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/7046A194A
Safari 6.0"
news_lst = []

begin
  response = @connection.get('news-list.json')
  body     = response.body.encode('utf-8', {invalid: :replace, undef: :replace, replace: ''})
  json     = JSON.parse(body)
  # puts json
  json.each do |item|
    item.each do |key, news_list|
      news_list.each do |news|
        news_lst.push({
                        id:           news["news_id"],
                        ony_title:        news["title"],
                        title:        news["title_with_ruby"],
                        publish_date: news["news_publication_time"],
                        full_url:     news["news_web_url"]
                      })
      end
    end
  end
rescue => e
  puts e.message
end


def generate_html(data_list)
  begin
    data_list.each { |item|
      # read all, get each id
      web_url   = "#{item[:id]}/#{item[:id]}.html"
      response  = @connection.get(web_url)
      page      = Nokogiri::HTML(response.body)
      title     = page.css("#newstitle")
      content   = page.css("#newsarticle")
      full_post = item[:full_url]
      only_title = item[:only_title]

      puts "start read erb, and create html file ...."
      renderer = ERB.new(File.read("index.html.erb"))
      result   = renderer.result(binding)

      html_file = "#{item[:id]}.html"

      File.open(html_file, 'w') do |f|
        puts "write #{html_file} start"
        f.write(result)
      end

    }

  rescue => e
    puts e.message
  end

end

generate_html(news_lst)